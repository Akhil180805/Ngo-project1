<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Analytics</title>
    <style>
        /* Your CSS styles here */
    </style>
</head>
<body>
    <h1>Student Analytics</h1>
    <h2>Quiz Results</h2>
    <?php
    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ngo1";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch quiz results from the database
    $sql = "SELECT * FROM quiz_results";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "Marks: " . $row["marks"] . "<br>";
        }
    } else {
        echo "No quiz results found.";
    }

    $conn->close();
    ?>
</body>
</html>
