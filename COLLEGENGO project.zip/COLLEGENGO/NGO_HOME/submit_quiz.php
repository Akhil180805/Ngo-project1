<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ngo1";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process quiz submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch and sanitize quiz answers
    $q1 = mysqli_real_escape_string($conn, $_POST['q1']);
    $q2 = mysqli_real_escape_string($conn, $_POST['q2']);
    $q3 = mysqli_real_escape_string($conn, $_POST['q3']);
    $q4 = mysqli_real_escape_string($conn, $_POST['q4']);
    // Add more questions as needed
    
    // Calculate total marks
    $total_marks = 0;
    if ($q1 == 'a') $total_marks += 1;
    if ($q2 == 'c') $total_marks += 1;
    if ($q3 == 'c') $total_marks += 1;
    if ($q4 == 'b') $total_marks += 1;
    // Add more questions as needed
    
    // Insert marks into database
    $sql = "INSERT INTO quiz_results (marks) VALUES ($total_marks)";
    if ($conn->query($sql) === TRUE) {
        echo "Quiz submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
