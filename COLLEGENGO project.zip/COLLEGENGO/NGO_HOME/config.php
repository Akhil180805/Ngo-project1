<?php

$conn = mysqli_connect('localhost','root','','ngo') or die('connection failed');

?>