<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Analytics</title>
    <style>
        .container {
            display: flex;
        }
        
        .student-list {
            flex: 30%;
            padding-right: 20px;
            display: flex;
            flex-wrap: wrap;
        }
        
        .student {
            cursor: pointer;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            padding: 5px;
            width: calc(33.33% - 10px);
            text-align: center;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        
        .student:hover {
            background-color: #f0f0f0;
            transform: translateY(-5px);
        }
        
        .student-container {
            display: none;
            flex: 70%;
            flex-direction: column;
            position: absolute;
            top: 50px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .student-container.active {
            display: flex;
        }
        
        .report {
            margin-top: 10px;
        }
        
        canvas {
            margin-top: 20px;
            width: 100%;
            max-width: 400px;
            height: auto;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="student-list">
            <?php
            // Assuming $students is an array of student names fetched from the database
            $students = ['Avni', 'Rahul', 'Poem', 'Akhil', 'Sonar', 'Bisha', 'Shreya'];
            foreach ($students as $student) {
                echo '<div class="student" onclick="toggleStudentDetails(\'' . strtolower($student) . '\')">' . $student . '</div>';
            }
            ?>
        </div>
        <?php
        foreach ($students as $student) {
            echo '<div id="' . strtolower($student) . 'Container" class="student-container">
            <h2>' . $student . '</h2>
            <div class="report">
                <h3>Analytics</h3>
                <p>Physics: ' . rand(60, 100) . '</p>
                <p>Chemistry: ' . rand(60, 100) . '</p>
                <p>Maths: ' . rand(60, 100) . '</p>
            </div>
            <canvas id="' . strtolower($student) . 'Graph" width="400" height="300"></canvas>
        </div>';
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        function toggleStudentDetails(studentName) {
            var container = document.getElementById(studentName + 'Container');
            if (container.classList.contains('active')) {
                container.classList.remove('active');
            } else {
                var activeContainers = document.querySelectorAll('.student-container.active');
                activeContainers.forEach(function(activeContainer) {
                    activeContainer.classList.remove('active');
                });
                container.classList.add('active');
                generateGraph(studentName);
            }
        }

        function generateGraph(studentName) {
            var canvas = document.getElementById(studentName + 'Graph');
            var ctx = canvas.getContext('2d');
            var marks = getStudentMarks(studentName);

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Physics', 'Chemistry', 'Maths'],
                    datasets: [{
                        label: 'Marks',
                        data: [marks.physics, marks.chemistry, marks.maths],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0)',
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            });
        }

        function getStudentMarks(studentName) {
            // Dummy data for demonstration
            var marks = {
                physics: Math.floor(Math.random() * 100),
                chemistry: Math.floor(Math.random() * 100),
                maths: Math.floor(Math.random() * 100)
            };

            return marks;
        }
    </script>
</body>

</html>