<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <style>
        /* Your CSS styles here */
    </style>
</head>
<body>
    <h1>Quiz</h1>
    <form action="submit_quiz.php" method="post">
        <h2>Architecture Questions</h2>
        <p>1. What is the tallest building in the world?</p>
        <input type="radio" name="q1" value="a"> A. Burj Khalifa<br>
        <input type="radio" name="q1" value="b"> B. Shanghai Tower<br>
        <input type="radio" name="q1" value="c"> C. Abraj Al Bait Clock Tower<br>
        <p>2. Who designed the Sydney Opera House?</p>
        <input type="radio" name="q2" value="a"> A. Frank Gehry<br>
        <input type="radio" name="q2" value="b"> B. Zaha Hadid<br>
        <input type="radio" name="q2" value="c"> C. Jørn Utzon<br>

        <h2>Physics Questions</h2>
        <p>3. What is the SI unit of force?</p>
        <input type="radio" name="q3" value="a"> A. Watt<br>
        <input type="radio" name="q3" value="b"> B. Joule<br>
        <input type="radio" name="q3" value="c"> C. Newton<br>
        <p>4. Who formulated the theory of relativity?</p>
        <input type="radio" name="q4" value="a"> A. Isaac Newton<br>
        <input type="radio" name="q4" value="b"> B. Albert Einstein<br>
        <input type="radio" name="q4" value="c"> C. Galileo Galilei<br>

        <!-- Add more questions here -->

        <button type="submit">Submit Quiz</button>
    </form>
</body>
</html>
